#!/bin/bash
javac *.java